import React from 'react'
import Logo from '../assets/images/logo.svg'

const Navbar = () => {
  return (
    <nav className='__navbar'>
        <div className='container'>
            <img src={Logo} alt="" />
            <div class="links">
                <p>Home</p>
                <p>Categories</p>
                <p>Products</p>
                <p>Contact</p>
            </div>
            <div className='icons'>
                <i class="fa-regular fa-magnifying-glass"></i>
                <i class="fa-regular fa-shuffle"></i>
                <i class="fa-regular fa-heart"></i>
                <i class="fa-regular fa-shopping-bag"></i>
            </div>
        </div>
    </nav>
  )
}

export default Navbar