import React from 'react'
import Bg from '../assets/images/bg.png'
import ProductPlaceholder from '../assets/images/product-placeholder.png'
import TopLeftDark from '../assets/images/top-left-dark.svg'
import BottomRightDark from '../assets/images/bottom-right-dark.svg'

const Flashsale2 = () => {
  return (
    <section className='__flashsale2'>
        <div className='container'>
            <div className='top-items'>
                <div className='item'>
                    <img src={ProductPlaceholder} alt='placeholder'/>
                    <div className='item-body'>
                        <p>Category</p>
                        <h1>Modern Black Blouse</h1>
                        <div className='d-flex justify-content-between align-items-center w-100'>
                            <div className='text-theme'>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                            </div>
                        </div>
                        <div className='prices'>
                            <p className='item-new-price'>$49.00</p>
                        </div>
                    </div>
                </div>
                <div className='item'>
                    <img src={ProductPlaceholder} alt='placeholder'/>
                    <div className='item-body'>
                        <p>Category</p>
                        <h1>Modern Black Blouse</h1>
                        <div className='d-flex justify-content-between align-items-center w-100'>
                            <div className='text-theme'>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                            </div>
                        </div>
                        <div className='prices'>
                            <p className='item-new-price'>$49.00</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className='right-object'>
                <div className='right-object-info'>
                    <h1>2 FOR $29</h1>
                    <button className='btn-theme-light'>FLASH SALE
                        <img id='top-left' src={TopLeftDark} alt='#'/>
                        <img id='bottom-right' src={BottomRightDark} alt='#'/>
                    </button>
                </div>
                <img src={Bg} alt='placeholder'/>
            </div>
            <div className='bottom-items'>
            <div className='item'>
                    <img src={ProductPlaceholder} alt='placeholder'/>
                    <div className='item-body'>
                        <p>Category</p>
                        <h1>Modern Black Blouse</h1>
                        <div className='d-flex justify-content-between align-items-center w-100'>
                            <div className='text-theme'>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                            </div>
                        </div>
                        <div className='prices'>
                            <p className='item-new-price'>$49.00</p>
                        </div>
                    </div>
                </div>
                <div className='item'>
                    <img src={ProductPlaceholder} alt='placeholder'/>
                    <div className='item-body'>
                        <p>Category</p>
                        <h1>Modern Black Blouse</h1>
                        <div className='d-flex justify-content-between align-items-center w-100'>
                            <div className='text-theme'>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                                <i class="fa-solid fa-star"></i>
                            </div>
                        </div>
                        <div className='prices'>
                            <p className='item-new-price'>$49.00</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  )
}

export default Flashsale2