import React from 'react'
import RightImage from '../assets/images/img-2.svg';
import LeftImage from '../assets/images/img-1.svg';
import TopLeft from '../assets/images/top-left.svg';
import BottomRight from '../assets/images/bottom-right.svg';

const Showcase = () => {
  return (
    <section className='__showcase'>
        <div className='container-fluid'>
            <img className='fr-1' src={RightImage} alt='' /> 
            <div className='shop-now'>
              <h1>Sale Up To 50% Off</h1>
              <p>Online shopping free home delivery over $100</p>
              <button className='btn-theme'>SHOP NOW
                <img id='top-left' src={TopLeft} alt=''></img>
                <img id='bottom-right' src={BottomRight} alt=''></img>
              </button>
            </div>
            <img className='fr-1' src={LeftImage} alt='' /> 
        </div>
    </section>
  )
}

export default Showcase