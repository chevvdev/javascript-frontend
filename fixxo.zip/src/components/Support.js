import React from 'react'
import FirstIcon from '../assets/images/first-icon.svg'
import SecondIcon from '../assets/images/second-icon.svg'
import ThirdIcon from '../assets/images/third-icon.svg'
import FourthIcon from '../assets/images/fourth-icon.svg'

const Support = () => {
  return (
    <section className='__support'>
        <div className='container'>
            <div className='object-1'>
                <img src={FirstIcon} alt='icon'/>
                <h1>Customer support</h1>
                <p>Village did removed enjoyed explain talking</p>
            </div>
            <div className='object-2'>
                <img src={SecondIcon} alt='icon'/>
                <h1>Secured Payment</h1>
                <p>Village did removed enjoyed explain talking</p>
            </div>
            <div className='object-3'>
                <img src={ThirdIcon} alt='icon'/>
                <h1>Free home Delivery</h1>
                <p>Village did removed enjoyed explain talking</p>
            </div>
            <div className='object-4'>
                <img src={FourthIcon} alt='icon'/>
                <h1>30 Day Reuters</h1>
                <p>Village did removed enjoyed explain talking</p>
            </div>
        </div>
    </section>
  )
}

export default Support