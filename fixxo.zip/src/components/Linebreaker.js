import React from 'react'
import LineIcon from '../assets/images/line-icon.svg'

const Linebreaker = () => {
  return (
    <section className='__linebreaker'>
        <div className='container'>
            <img src={LineIcon} alt='placeholder'/>
        </div>
    </section>
  )
}

export default Linebreaker