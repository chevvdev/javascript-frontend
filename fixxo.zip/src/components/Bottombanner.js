import React from 'react'

const Bottombanner = () => {
  return (
    <section className='__bottom-banner'>
      <div className='icons'>
          <i class="fa-brands fa-facebook-f"></i>
          <i class="fa-brands fa-instagram"></i>
          <i class="fa-brands fa-twitter"></i>
          <i class="fa-brands fa-google"></i>
          <i class="fa-brands fa-linkedin"></i>
      </div>
      <p>© 2022 Fixxo. All Rights Reserved</p>
    </section>
  )
}

export default Bottombanner