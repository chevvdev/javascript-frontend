import React from 'react'
import TopLeft from '../assets/images/top-left.svg'
import BottomRight from '../assets/images/bottom-right.svg'
import Bg from '../assets/images/bg.png'
import ProductPlaceholder from '../assets/images/product-placeholder.png'
import TopLeftDark from '../assets/images/top-left-dark.svg'
import BottomRightDark from '../assets/images/bottom-right-dark.svg'

const Flashsale = () => {
  return (
    <section className='__flashsale'>
        <div className='container'>
            <div className='left-object'>
                <div className='left-object-info'>
                    <h1>2 FOR $29</h1>
                    <button className='btn-theme-light'>FLASH SALE
                        <img id='top-left' src={TopLeftDark} alt='#'/>
                        <img id='bottom-right' src={BottomRightDark} alt='#'/>
                    </button>
                </div>
                <img src={Bg} alt=''/>
            </div>
            <div className='item'>
                <img src={ProductPlaceholder} alt='#'/>
                <div className='item-card'>
                    <div className='item-menu'>
                        <i class="fa-regular fa-heart"></i>
                        <i class="fa-regular fa-shuffle"></i>
                        <i class="fa-regular fa-shopping-bag"></i>
                    </div>
                    <button className='btn-theme'>QUICK VIEW
                        <img id='top-left' src={TopLeft} alt='#'/>
                        <img id='bottom-right' src={BottomRight} alt='#'/>
                    </button>
                </div>
                <div className='item-body'>
                    <p>Category</p>
                    <h1>Modern Black Blouse</h1>
                </div>
                <div className='d-flex justify-content-between align-items-center w-100'>
                    <div className='text-theme'>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
                <div className='prices'>
                    <p className='item-new-price'>$30.00</p>
                </div>
            </div>
            <div className='item'>
                <img src={ProductPlaceholder} alt='#'/>
                <div className='item-card'>
                    <div className='item-menu'>
                        <i class="fa-regular fa-heart"></i>
                        <i class="fa-regular fa-shuffle"></i>
                        <i class="fa-regular fa-shopping-bag"></i>
                    </div>
                    <button className='btn-theme'>QUICK VIEW
                        <img id='top-left' src={TopLeft} alt='#'/>
                        <img id='bottom-right' src={BottomRight} alt='#'/>
                    </button>
                </div>
                <div className='item-body'>
                    <p>Category</p>
                    <h1>Modern Black Blouse</h1>
                </div>
                <div className='d-flex justify-content-between align-items-center w-100'>
                    <div className='text-theme'>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
                <div className='prices'>
                    <p className='item-new-price'>$30.00</p>
                </div>
            </div>
            <div className='bottom-items'>
            <div className='item'>
                <img src={ProductPlaceholder} alt='#'/>
                <div className='item-card'>
                    <div className='item-menu'>
                        <i class="fa-regular fa-heart"></i>
                        <i class="fa-regular fa-shuffle"></i>
                        <i class="fa-regular fa-shopping-bag"></i>
                    </div>
                    <button className='btn-theme'>QUICK VIEW
                        <img id='top-left' src={TopLeft} alt='#'/>
                        <img id='bottom-right' src={BottomRight} alt='#'/>
                    </button>
                </div>
                <div className='item-body'>
                    <p>Category</p>
                    <h1>Modern Black Blouse</h1>
                </div>
                <div className='d-flex justify-content-between align-items-center w-100'>
                    <div className='text-theme'>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
                <div className='prices'>
                    <p className='item-new-price'>$30.00</p>
                </div>
            </div>
            <div className='item'>
                <img src={ProductPlaceholder} alt='#'/>
                <div className='item-card'>
                    <div className='item-menu'>
                        <i class="fa-regular fa-heart"></i>
                        <i class="fa-regular fa-shuffle"></i>
                        <i class="fa-regular fa-shopping-bag"></i>
                    </div>
                    <button className='btn-theme'>QUICK VIEW
                        <img id='top-left' src={TopLeft} alt='#'/>
                        <img id='bottom-right' src={BottomRight} alt='#'/>
                    </button>
                </div>
                <div className='item-body'>
                    <p>Category</p>
                    <h1>Modern Black Blouse</h1>
                </div>
                <div className='d-flex justify-content-between align-items-center w-100'>
                    <div className='text-theme'>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                </div>
                <div className='prices'>
                    <p className='item-new-price'>$30.00</p>
                </div>
            </div>
        </div>
    </div>
</section>
  )
}

export default Flashsale