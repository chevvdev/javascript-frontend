import React from 'react'
import TopLeft from '../assets/images/top-left.svg'
import BottomRight from '../assets/images/bottom-right.svg'
import ProductPlaceholder from '../assets/images/product-placeholder.png'

const Products = () => {
  return (
    <section className='__products'>
      <div className='container'>
        <div className='item'>
          <div className='item-card'>
            <div className='item-menu'>
              <i class="fa-regular fa-heart"></i>
              <i class="fa-regular fa-shuffle"></i>
              <i class="fa-regular fa-shopping-bag"></i>
            </div>
            <button className='btn-theme'>QUICK VIEW
              <img id='top-left' src={TopLeft} alt=''/>
              <img id='bottom-right' src={BottomRight} alt=''/>
            </button>
          </div>
          <img id='product-placeholder' src={ProductPlaceholder} alt=''/>
          <div className='item-body'>
            <p>Category</p>
            <h1>Modern Black Blouse</h1>
            <div className='d-flex justify-content-between align-items-center w-100'>
              <div className='text-theme'>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
              </div>
            </div>
            <div className='prices'>
              <p className='item-old-price'>$35.00</p>
              <p className='item-new-price'>$30.00</p>
            </div>
          </div>
        </div>
        <div className='item'>
          <div className='item-card'>
            <div className='item-menu'>
              <i class="fa-regular fa-heart"></i>
              <i class="fa-regular fa-shuffle"></i>
              <i class="fa-regular fa-shopping-bag"></i>
            </div>
            <button className='btn-theme'>QUICK VIEW
              <img id='top-left' src={TopLeft} alt=''/>
              <img id='bottom-right' src={BottomRight} alt=''/>
            </button>
          </div>
          <img id='product-placeholder' src={ProductPlaceholder} alt=''/>
          <div className='item-body'>
            <p>Category</p>
            <h1>Modern Black Blouse</h1>
            <div className='d-flex justify-content-between align-items-center w-100'>
              <div className='text-theme'>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
              </div>
            </div>
            <div className='prices'>
              <p className='item-old-price'>$35.00</p>
              <p className='item-new-price'>$30.00</p>
            </div>
          </div>
        </div>
        <div className='item'>
          <div className='item-card'>
            <div className='item-menu'>
              <i class="fa-regular fa-heart"></i>
              <i class="fa-regular fa-shuffle"></i>
              <i class="fa-regular fa-shopping-bag"></i>
            </div>
            <button className='btn-theme'>QUICK VIEW
              <img id='top-left' src={TopLeft} alt=''/>
              <img id='bottom-right' src={BottomRight} alt=''/>
            </button>
          </div>
          <img id='product-placeholder' src={ProductPlaceholder} alt=''/>
          <div className='item-body'>
            <p>Category</p>
            <h1>Modern Black Blouse</h1>
            <div className='d-flex justify-content-between align-items-center w-100'>
              <div className='text-theme'>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
              </div>
            </div>
            <div className='prices'>
              <p className='item-old-price'>$35.00</p>
              <p className='item-new-price'>$30.00</p>
            </div>
          </div>
        </div>
        <div className='item'>
          <div className='item-card'>
            <div className='item-menu'>
              <i class="fa-regular fa-heart"></i>
              <i class="fa-regular fa-shuffle"></i>
              <i class="fa-regular fa-shopping-bag"></i>
            </div>
            <button className='btn-theme'>QUICK VIEW
              <img id='top-left' src={TopLeft} alt=''/>
              <img id='bottom-right' src={BottomRight} alt=''/>
            </button>
          </div>
          <img id='product-placeholder' src={ProductPlaceholder} alt=''/>
          <div className='item-body'>
            <p>Category</p>
            <h1>Modern Black Blouse</h1>
            <div className='d-flex justify-content-between align-items-center w-100'>
              <div className='text-theme'>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
              </div>
            </div>
            <div className='prices'>
              <p className='item-old-price'>$35.00</p>
              <p className='item-new-price'>$30.00</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Products