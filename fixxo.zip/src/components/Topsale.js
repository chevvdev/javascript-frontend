import React from 'react'
import Left from '../assets/images/left.svg'
import Right from '../assets/images/right.svg'
import TopLeft from '../assets/images/top-left.svg'
import BottomRight from '../assets/images/bottom-right.svg'
import TopLeftDark from '../assets/images/top-left-dark.svg'
import BottomRightDark from '../assets/images/bottom-right-dark.svg'

const Topsale = () => {
  return (
    <section className='__topsale'>
        <div className='container'>
        <div className='left-object'>
          <img src={Left} alt=''/>
          <div className='info'>
            <h1>Pamela Reif's</h1>
            <h1>Top Picks</h1>
            <button className='btn-theme-dark'>SHOP NOW
              <img id='top-left' src={TopLeft} alt=''/>
              <img id='bottom-right' src={BottomRight} alt=''/>
            </button>
          </div>
        </div>
        <div className='right-object'>
          <div className='info'>
            <h1>Let's be</h1>
            <h1>Conscious</h1>
            <button className='btn-theme-light'>SHOP NOW
              <img id='top-left' src={TopLeftDark} alt=''/>
              <img id='bottom-right' src={BottomRightDark} alt=''/>
            </button>
          </div>
          <img src={Right} alt=''/>
        </div>
      </div>

    </section>
  )
}

export default Topsale