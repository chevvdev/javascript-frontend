import './App.min.css';
import Navbar from './components/Navbar';
import Showcase from './components/Showcase';
import Products from './components/Products';
import Topsale from './components/Topsale';
import Flashsale from './components/Flashsale';
import Flashsale2 from './components/Flashsale2';
import Linebreaker from './components/Linebreaker';
import Support from './components/Support';
import Bottombanner from './components/Bottombanner';


function App() {
  return (
    <>
      <Navbar />
      <Showcase />
      <Products />
      <Products />
      <Topsale />
      <Flashsale />
      <Flashsale2 />
      <Linebreaker />
      <Support />
      <Bottombanner />
    </>
  );
}

export default App;
